const express = require('express');
// const merchantController = require('../../controllers/merchant.controller');

const router = express.Router();

// router.route('/profile/:slug').get(merchantController.getMerchantWithSlug);

module.exports = router;
